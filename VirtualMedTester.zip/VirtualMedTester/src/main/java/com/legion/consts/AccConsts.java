package com.legion.consts;

public class AccConsts {
    public final static String baseURL = "https://legion.virtualmedclaims.com/login";
    public static final String doctorUsername = "DOCTOR";
    public static final String doctorPassword = "Welcome1234!";
}
